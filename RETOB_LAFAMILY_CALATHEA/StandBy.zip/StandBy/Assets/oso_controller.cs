﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class oso_controller : MonoBehaviour
{
    public float speed = 2f;

    public float jumpPower = 6f;

    private Rigidbody2D rb2d;


    public float maxspeed = 3f;

    public bool grounded;

    // Start is called before the first frame update
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.UpArrow) && grounded)
        {
            rb2d.AddForce(Vector2.up * jumpPower, ForceMode2D.Impulse);
        }


        float h = Input.GetAxis("Horizontal");

        rb2d.AddForce(Vector2.right * speed * h);

        float limitedSpeed = Mathf.Clamp(rb2d.velocity.x, -maxspeed, maxspeed);
        rb2d.velocity = new Vector2(limitedSpeed, rb2d.velocity.y);

        //float direccionV = Input.GetAxis("Vertical");

        //rb2d.velocity = new Vector3(direccionV * speed, rb2d.velocity.y, transform.position.z);
    }

    void fixedUpdate()
    {

    }
}
